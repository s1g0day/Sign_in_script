# 52pojie
破解文字点击验证码，并模拟登录吾爱破解，并进行自动签到
 ![image]( https://github.com/guapier/52pojie/blob/master/QQ20190222-125335-HD.gif)

